from django.forms import ModelForm 
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *

class CreateUserForm_job(ModelForm):  
    class Meta:
        model = user
        fields = ('__all__') 

class imagem_form(ModelForm):  
    class Meta:
        model = imagem
        fields = ('__all__') 
 