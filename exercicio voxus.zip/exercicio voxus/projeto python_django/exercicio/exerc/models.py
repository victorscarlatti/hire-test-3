from django.db import models

# Create your models here.

class user(models.Model):  
    username = models.CharField(primary_key=True, max_length=50, default=None, blank=False, null=False)
    email = models.EmailField(max_length=25, default=None, blank=False, null=False)
    password1 = models.CharField(max_length=11,default=None, blank=False, null=False)
    password2 = models.CharField(max_length=11,default=None, blank=False, null=False)
    genero = models.CharField(max_length=100,default=None, blank=False, null=False)
    data_nascimento = models.DateField(default=None, blank=False, null=False)

class imagem(models.Model): 
    id = models.CharField(primary_key=True, default=None, blank=False, null=False, max_length=500)# email + sequencial
    imagem = models.TextField(default=None, blank=False, null=False)

