
from django.urls import path


from exerc import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [

    
    path('logout_user_job', views.logoutUser_job, name='logout_user_job'),
    path('', views.imagem, name='imagem'),
    path('signin', views.signin, name='signin'),
    path('signup', views.signup, name='signup'),

]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)