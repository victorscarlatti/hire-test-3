from django.apps import AppConfig


class ExercConfig(AppConfig):
    name = 'exerc'
