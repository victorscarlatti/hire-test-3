from django.shortcuts import get_object_or_404, redirect, render
from .models import *
from .forms import *
from django.http import HttpResponse, JsonResponse
from django.contrib.sites.shortcuts import get_current_site
import time
import datetime
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from base64 import b64encode 
import string
import random
from reportlab.platypus.xpreformatted import XPreformatted
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.utils import ImageReader
from io import StringIO 
from _io import BytesIO
import requests
import re
import base64
# Create your views here.


def signup(request):      
    messages = ''
    form = CreateUserForm_job()
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password2']
        a1 = User.objects.filter(username=username)
        if len(a1) > 0:
            messages = 'Usuario Já Existente'
        user = User.objects.create_user(username=request.POST['username'],email=request.POST['email'],password=request.POST['password2'])       
        user = authenticate(request, username=username, password=password)
        if user is not None:
            uu = User.objects.filter(username=username)
            r = request.POST.copy()
            r.update({'data_nascimento': datetime.datetime.strptime(request.POST['data_nascimento'] ,'%m/%d/%Y').strftime('%Y-%d-%m') })
            form = CreateUserForm_job(r)
            if form.is_valid():
                form.save()
            print(form.errors)
            if uu is not None:
                login(request, user)
                return redirect('imagem') 
    context = {'form':form,'messages':messages}
    return render(request, "signup2.html" ,context)

@login_required(login_url='signin')
def logoutUser_job(request):
    logout(request)
    return redirect('signin')

@login_required(login_url='signin')
def imagem(request):
    messages = ''
    form = imagem_form()

    if request.method == 'POST':
        r = request.POST.copy()
        a = request.FILES['imagem']
        a = base64.b64encode(a.read())
        if "image" not in request.FILES['imagem'].content_type:
            return HttpResponse(status=404)
        r.update({'id': request.user.username+str(len(User.objects.filter(username=request.user.username)) + 1)})
        r.update({'imagem': str(a)})
        form = imagem_form(r)
        if form.is_valid():
            form.save()
        print(form.errors)
    
    form = imagem_form()
    context = {'form':form,'messages':messages}
    return render(request, "imagem.html" ,context)
  
def signin(request): 
    messages = '' 
    if request.user.is_authenticated:
        return redirect('imagem')
    else:
        if request.method == 'POST':         
            uu = User.objects.filter(email=request.POST.get('cpf') ).values()
            for u in uu:
                username = u['username']        
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:               
                if uu is not None:
                    login(request, user)
                    return redirect('imagem')
            else: 
                messages = 'Dados Incorretos' 
    context = {'messages':messages}
    return render(request, "signin2.html" ,context)

